﻿namespace Microsoft.eShopWeb.Web.ViewModels.Manage;

public class ShowRecoveryCodesViewModel
{
    public string[]? RecoveryCodes { get; set; }
}

