export class AddCategoryRequest{

  name:string;
  urlHandle:string;

}
