export const environment = {
  apiBaseUrl: 'https://localhost:44364',
};
